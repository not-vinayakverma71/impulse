# Impulse - Standalone Package

## Quick Start

```bash
./impulse
```

That's it! Everything is bundled.

## What's Included

- ✅ Impulse Editor (release build)
- ✅ LSP Server (auto-starts)
- ✅ VNC Viewer (if available on build system)
- ✅ xdotool (Linux automation)
- ✅ wmctrl (window management)
- ✅ git (if available)
- ✅ All required libraries

## Installation (Optional)

To install system-wide:
```bash
sudo cp -r bin/* /usr/local/bin/
sudo cp -r lib/* /usr/local/lib/
sudo ldconfig
```

Or for current user:
```bash
mkdir -p ~/.local
cp -r bin ~/.local/
cp -r lib ~/.local/
export PATH="$HOME/.local/bin:$PATH"
```

## Features

- 🤖 AI-Powered Coding
- 🔍 LSP Integration (5000 files)
- 📊 VNC Tabs
- 🎨 Modern UI
- 🔧 Git Integration

## Uninstall

```bash
# If installed system-wide
sudo rm -f /usr/local/bin/impulse /usr/local/bin/language_server_impulse_x64

# If installed to user
rm -rf ~/.local/bin/impulse ~/.local/bin/language_server_impulse_x64
```

## Logs

- `~/.local/share/lapce-debug/logs/lsp_server.log`
- `~/.local/share/lapce-debug/logs/lapce.*.log`

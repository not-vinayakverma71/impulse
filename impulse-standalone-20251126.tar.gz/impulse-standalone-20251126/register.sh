#!/bin/bash
# Registers this portable app with your system menu

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ICON_PATH="${DIR}/impulse.svg"
EXEC_PATH="${DIR}/impulse"

echo "📝 Registering Impulse..."

# Create desktop entry
mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/impulse-portable.desktop <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Impulse
Comment=AI-Powered Code Editor
Exec=${EXEC_PATH} --new --wait
Icon=${ICON_PATH}
Terminal=false
Categories=Development;IDE;
StartupWMClass=impulse
EOF

# Update database
update-desktop-database ~/.local/share/applications 2>/dev/null || true

echo "✅ Registered! You can now find Impulse in your app menu."
